import csv, os
arcpy.env.overwriteOutput = True
arcpy.AddMessage("Starting . . . ")

gdb = arcpy.GetParameterAsText(0)
tract = arcpy.GetParameterAsText(1)
csvFile = arcpy.GetParameterAsText(2)
areaName = arcpy.GetParameterAsText(3)
if areaName.find(" ") != -1:
    areaName = areaName.replace(" ","")
    arcpy.AddWarning("areaName input had spaces and has been updated to the following {0}".format(areaName)) 
table = "{0}_Poverty".format(areaName)
tablePath = os.path.join(gdb,table)
censusType = arcpy.GetParameterAsText(4)
censusPoly = os.path.join(gdb,table+"_{0}".format(censusType))
sql = arcpy.GetParameterAsText(5)

fields = {"geoid_census":["GeoID_Join","STRING"],
          "total_pop":["Total Population For Poverty","LONG"],
          "U50":["Under 50 Percent of Poverty","LONG"],
          "p50_99":["50 to 99 Percent of Povertyof Poverty","LONG"],
          "p99_124":["99 to 124 Percent of Poverty","LONG"],
          "p125_149":["125 to 149 Percent of Poverty","LONG"],
          "p140_184":["150 to 184 Percent of Poverty","LONG"],
          "p185_199":["185 to 199 Percent of Poverty","LONG"],
          "O200":["Over 200 Percent of Poverty","LONG"],
          "U100Tot":["Under 100 Percent of Poverty","LONG"],
          "prct_U100":["Percent Under 100 Percent of Poverty","FLOAT"],
          "U150Tot":["Under 150 Percent of Poverty","LONG"],
          "prct_U150":["Percent Under 150 Percent of Poverty","FLOAT"],
          "U200Tot":["Under 200 Percent of Poverty","LONG"],
          "prct_U2000":["Percent Under 200 Percent of Poverty","FLOAT"],
          }

arcpy.AddMessage("Creating a new table for the csv data")
arcpy.management.CreateTable(gdb,table)


tableFields = []
for field in fields:
    name = field
    alias = fields[field][0]
    dataType = fields[field][1]
    arcpy.AddMessage(name)
    arcpy.AddMessage(alias)
    tableFields.append(field)
    arcpy.management.AddField(tablePath,name,dataType,field_alias = alias)
    arcpy.AddMessage("Adding field {0} to the table".format(field))
    
    

fileRef = open(csvFile)
csvRef = csv.reader(fileRef)

arcpy.AddMessage("Inserting csv values to table, {0}".format(tablePath))
for row in csvRef:
    if csvRef.line_num <= 2:
        continue
    geoJoin = row[0][9:]
    totUnd100 = int(row[4])+int(row[6])
    totUnd150 = int(row[4])+int(row[6])+int(row[8])+int(row[10])
    totUnd200 = int(row[4])+int(row[6])+int(row[8])+int(row[10])+int(row[12])+int(row[14])
    if int(row[2]) != 0:
        prct_U100= round((totUnd100/float(row[2]))*100,2)
        prct_U150= round((totUnd150/float(row[2]))*100,2)
        prct_U200= round((totUnd200/float(row[2]))*100,2)
    else:
       prct_U100= -999
       prct_U150= -999
       prct_U200= -999
    value =  [geoJoin,int(row[2]),int(row[4]),int(row[6]),int(row[8]),int(row[10]),int(row[12]),
              int(row[14]),int(row[16]),totUnd100,prct_U100,totUnd150,prct_U150,totUnd200,prct_U200]
    cursor = arcpy.da.InsertCursor(tablePath,tableFields)
    arcpy.AddMessage(value)
    cursor.insertRow(value)
    del cursor

arcpy.AddMessage("Selecting out geographies to join table to")
arcpy.analysis.Select(tract,censusPoly,sql)
arcpy.AddMessage("Select has finished, joining the table to the new feature class")
arcpy.management.JoinField(censusPoly,"GEOID",tablePath,"geoid_census",tableFields)
arcpy.AddMessage("Finished")


